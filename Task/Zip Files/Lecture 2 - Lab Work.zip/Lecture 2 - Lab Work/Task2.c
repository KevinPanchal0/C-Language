#include<stdio.h>
void main(){
	int user=1234,pass=5678;
	int u,p;
	
	printf("Enter the UserName: ");
	scanf("%d",&u);
	
	if(user==u){
		printf("Enter the Password: ");
		scanf("%d",&p);
		
		if(pass==p){
			printf("Login Success!");
		}
		else{
			printf("Invalid Password");
		}
	}
	else{
		printf("Invalid UserName :(");
	}
	
}
