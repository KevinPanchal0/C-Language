#include<stdio.h>
void main(){
	printf("My Name is Kevin.\n");
	printf("My Age is 19.\n");
	printf("School name is Aadharshila.");
}
