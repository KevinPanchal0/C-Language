#include<stdio.h>
void main(){
	printf("*  *\n*    *\n*     *\n*      *\n*     * \n*    *\n*  *\n");
}

