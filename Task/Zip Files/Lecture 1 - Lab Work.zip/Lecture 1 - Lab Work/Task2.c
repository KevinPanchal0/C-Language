#include <stdio.h>  
#include <conio.h>  
int main ()  
{  
    char lwr;
    int ascii;  
      
    printf (" \n Enter the Lower Case Character: ");  
    scanf (" %c", &lwr);  
    ascii = lwr - 32;  
    printf (" %c character in the Upper case is: %c", lwr, ascii);  
      
    return 0;  
}  
