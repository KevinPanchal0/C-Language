#include <stdio.h>

int main() {
    int num1, num2, num3, num4, num5, max;

    printf("Enter the first number: ");
    scanf("%d", &num1);

    printf("Enter the second number: ");
    scanf("%d", &num2);

    printf("Enter the third number: ");
    scanf("%d", &num3);

    printf("Enter the fourth number: ");
    scanf("%d", &num4);

    printf("Enter the fifth number: ");
    scanf("%d", &num5);

    max = (num1 > num2) ? ((num1 > num3) ? ((num1 > num4) ? ((num1 > num5) ? num1 : num5) : ((num4 > num5) ? num4 : num5)) : ((num3 > num4) ? ((num3 > num5) ? num3 : num5) : ((num4 > num5) ? num4 : num5))) : ((num2 > num3) ? ((num2 > num4) ? ((num2 > num5) ? num2 : num5) : ((num4 > num5) ? num4 : num5)) : ((num3 > num4) ? ((num3 > num5) ? num3 : num5) : ((num4 > num5) ? num4 : num5)));

    printf("The maximum of %d, %d, %d, %d, and %d is %d\n", num1, num2, num3, num4, num5, max);

    return 0;
}

