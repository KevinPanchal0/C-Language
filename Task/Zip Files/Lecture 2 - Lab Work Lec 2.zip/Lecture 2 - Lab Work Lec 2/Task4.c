#include <stdio.h>

int main() {
    int num1, num2, num3, num4, num5, min;

    printf("Enter the first number: ");
    scanf("%d", &num1);

    printf("Enter the second number: ");
    scanf("%d", &num2);

    printf("Enter the third number: ");
    scanf("%d", &num3);

    printf("Enter the fourth number: ");
    scanf("%d", &num4);

    printf("Enter the fifth number: ");
    scanf("%d", &num5);

    if (num1 <= num2) {
        if (num1 <= num3) {
            if (num1 <= num4) {
                if (num1 <= num5) {
                    min = num1;
                } else {
                    min = num5;
                }
            } else {
                if (num4 <= num5) {
                    min = num4;
                } else {
                    min = num5;
                }
            }
        } else {
            if (num3 <= num4) {
                if (num3 <= num5) {
                    min = num3;
                } else {
                    min = num5;
                }
            } else {
                if (num4 <= num5) {
                    min = num4;
                } else {
                    min = num5;
                }
            }
        }
    } else {
        if (num2 <= num3) {
            if (num2 <= num4) {
                if (num2 <= num5) {
                    min = num2;
                } else {
                    min = num5;
                }
            } else {
                if (num4 <= num5) {
                    min = num4;
                } else {
                    min = num5;
                }
            }
        } else {
            if (num3 <= num4) {
                if (num3 <= num5) {
                    min = num3;
                } else {
                    min = num5;
                }
            } else {
                if (num4 <= num5) {
                    min = num4;
                } else {
                    min = num5;
                }
            }
        }
    }

    printf("The minimum of %d, %d, %d, %d, and %d is %d\n", num1, num2, num3, num4, num5, min);

    return 0;
}

