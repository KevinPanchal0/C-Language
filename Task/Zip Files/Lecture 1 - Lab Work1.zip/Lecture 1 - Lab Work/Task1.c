#include<stdio.h>
void cube(){
	int a,cube1;
	
	printf("Enter No. to get Cube: ");
	scanf("%d",&a);
	
	cube1=a*a*a;
	
	printf("%d is cube of %d",cube1,a);
}

void main(){
	cube();
}
