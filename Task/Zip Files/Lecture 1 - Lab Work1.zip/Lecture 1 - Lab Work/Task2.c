#include<stdio.h>
void divisible(){
	int a;
	
	printf("Enter No. to get Cube: ");
	scanf("%d",&a);
	
	if(a%3==0 && a%5==0){
		printf("It is divisible by 3 and 5");
	}
	else{
			printf("It is not divisible by 3 and 5");
	}
}

void main(){
		divisible();
}
