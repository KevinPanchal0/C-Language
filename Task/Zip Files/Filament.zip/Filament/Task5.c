#include <stdio.h>
#include <string.h>

int findStringLength(char matrix[][5], const char *target) {
    int rows = 3;
    int cols = 4;
    int i,j;
    for (i = 0; i < rows; ++i) {
        for (j = 0; j < cols; ++j) {
            if (matrix[i][j] == target[0]) { 
                if (strncmp(&matrix[i][j], target, strlen(target)) == 0) {
                    return strlen(target);
                }
            }
        }
    }

    return 0;
}

int main() {
    char matrix[][5] = {
        {'A', 'B', 'C', 'D'},
        {'E', 'F', 'G', 'H'},
        {'I', 'J', 'K', 'L'}
    };

	char *targetString = "FG";
    int result = findStringLength(matrix, targetString);

    printf("Length of '%s' in the 2D array: %d\n", targetString, result);

    return 0;
}

