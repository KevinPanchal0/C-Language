#include<stdio.h>
void main(){
	char op;
	int a,b;
	float c,d;
	
	printf("Enter the arithmetic operator such as (+, -, *, /): ");
	scanf("%c",&op);
	
	switch(op){
		case '+' : 
			printf("Enter the value of A: ");
			scanf("%d",&a);
			printf("Enter the value of B: ");
			scanf("%d",&b);
			
			printf("The Sum of %d and %d is %d",a,b,a+b);
			break;
			
		case '-' : 
			printf("Enter the value of A: ");
			scanf("%d",&a);
			printf("Enter the value of B: ");
			scanf("%d",&b);
			
			printf("The Sub. of %d and %d is %d",a,b,a-b);
			break;
			
		case '*' : 
			printf("Enter the value of A: ");
			scanf("%d",&a);
			printf("Enter the value of B: ");
			scanf("%d",&b);
			
			printf("The Multiplication of %d and %d is %d",a,b,a*b);
			break;
			
		case '/' : 
			printf("Enter the value of A: ");
			scanf("%f",&c);
			printf("Enter the value of B: ");
			scanf("%f",&d);
			
			printf("The Division of %.2f and %.2f is %.2f",c,d,c/d);
			break;
			
		default :
			printf("Enter only arithmetic operator such as (+, -, *, /)") ;
	}
}
